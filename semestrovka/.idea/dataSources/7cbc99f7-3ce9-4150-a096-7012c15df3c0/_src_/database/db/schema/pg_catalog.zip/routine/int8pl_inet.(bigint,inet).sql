create function int8pl_inet(bigint, inet) returns inet
IMMUTABLE
LANGUAGE SQL
AS $$
select $2 + $1
$$;
