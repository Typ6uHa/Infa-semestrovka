create function user_role() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
		NEW.role = 2;
		return new;
	END;
$$;
