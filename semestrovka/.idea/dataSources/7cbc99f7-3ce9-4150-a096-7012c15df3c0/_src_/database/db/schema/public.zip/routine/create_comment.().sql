create function create_comment() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
		NEW.date_comment = now();
		return new;
	END;
$$;
