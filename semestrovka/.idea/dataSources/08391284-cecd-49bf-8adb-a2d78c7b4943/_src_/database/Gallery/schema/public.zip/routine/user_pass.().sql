create function user_pass() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
		if (TG_OP = 'UPDATE') THEN
			IF ((NEW.password) != (OLD.password)) THEN
				NEW.password := md5(NEW.password);
			end IF;
		ELSEIF (TG_OP = 'INSERT') THEN
			NEW.password := md5(NEW.password);
			NEW.date_reg = now();
		END IF;
		return new;
	END;
$$;
