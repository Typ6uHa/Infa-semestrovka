create function create_post() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
		NEW.like = 0;
		NEW.dislike = 0;
		NEW.date_post = now();
		return new;
	END;
$$;
