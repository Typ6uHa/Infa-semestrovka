CREATE VIEW x AS SELECT comment.id,
    comment.user_id,
    comment.topic_id,
    comment.comment_text,
    comment.date_comment
   FROM comment;
